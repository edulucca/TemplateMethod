/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padroescomportamentais;

import templatemethod.Cafe;
import templatemethod.CafeComIngrediente;
import templatemethod.Cha;
import templatemethod.ChaComIngredientes;

/**
 *
 * @author eduar
 */
public class PadroesComportamentais {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        exemploTemplateMethod();
    }
    
    public static void exemploTemplateMethod(){
        Cha cha = new Cha();
        Cafe cafe = new Cafe();
        
        System.out.println("\nFazendo Chá...");
        cha.prepararReceita();
        
        System.out.println("\nFazendo Cafe...");
        cafe.prepararReceita();
        
        CafeComIngrediente cafeComArranjo = new CafeComIngrediente();
        ChaComIngredientes chaComArranjo = new ChaComIngredientes();
        
        System.out.println("\nFazendo café com ingredientes...");
        cafeComArranjo.prepararReceita();
        
        System.out.println("\nFazendo chá com ingredientes...");
        chaComArranjo.prepararReceita();
    }
}
