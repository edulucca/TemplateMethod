
package templatemethod;

public class Cha extends BebidasComCafeina{

    @Override
    void infusao() {
        System.out.println("Molhando o chá...");
    }

    @Override
    void adicionarIngredientes() {
        System.out.println("Adicionando Limão...");
    }
    
}
