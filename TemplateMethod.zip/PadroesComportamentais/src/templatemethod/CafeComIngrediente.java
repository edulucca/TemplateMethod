/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package templatemethod;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author eduar
 */
public class CafeComIngrediente extends BebidasComCafeComIngredientes{

    @Override
    void adicionarIngrediente() {
        System.out.println("Adicionando açucar e leite...");
    }

    @Override
    void infusao() {
        System.out.println("Pingando café através do filtro...");
    }
    
    public boolean clienteDesejaIngredientes(){
        String responder = getObterEntradaUsuario();
        
        if(responder.toLowerCase().startsWith("s")){
            return true;
        }
        else{
            return false;
        }
    }

    private String getObterEntradaUsuario() {
        String responder = null;
		
        System.out.print("Você gostaria de leite e açúcar em seu café(s/n)? ");

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        try {
                responder = in.readLine();
        }catch (IOException ioe) {
                System.err.println("Erro de IO ao tentar ler sua resposta.");
        }

        if (responder == null) {
                return "no";
        }
        return responder;
    }
}
