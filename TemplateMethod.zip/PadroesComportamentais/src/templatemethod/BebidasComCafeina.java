/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package templatemethod;

/**
 *
 * @author eduar
 */
public abstract class BebidasComCafeina {
    public final void prepararReceita(){
        ferverAgua();
        infusao();
        derramarNaXicara();
    }
    
    void ferverAgua(){
        System.out.println("Agua fervendo...");
    }
    
    abstract void infusao();
    
    abstract void adicionarIngredientes();
    
    void derramarNaXicara(){
        System.out.println("Derramando agua na xícara...");
    }
    
    
}
