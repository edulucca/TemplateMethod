/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package templatemethod;

/**
 *
 * @author eduar
 */
public class Cafe extends BebidasComCafeina{

    @Override
    void infusao() {
        System.out.println("Pingando café através do filtro...");
    }

    @Override
    void adicionarIngredientes() {
        System.out.println("Adicionando açucar e leite...");
    }
    
}
