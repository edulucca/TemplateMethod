package templatemethod;

public abstract class BebidasComCafeComIngredientes {
    public void prepararReceita(){
        ferverAgua();
        infusao();
        derramarNaXicara();
        
        if(clienteDesejaIngrediente()){
            adicionarIngrediente();
        }
    }
    
    abstract void adicionarIngrediente();
    
    abstract void infusao();
    
    void ferverAgua(){
        System.out.println("Água fervente...");
    }

    void derramarNaXicara() {
        System.out.println("Derramando na Xícara...");
    }

    boolean clienteDesejaIngrediente() {
        return true;
    }
}
